﻿using ClassMarks.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;

namespace ClassMarks
{
    class Program
    {
        static async Task Main(string[] args)
        {
            string requestURI = "https://raw.githubusercontent.com/tester1-1/testdata/main/data.json";
            Console.WriteLine(JsonConvert.SerializeObject(await GetMinMaxValues(requestURI)));
            Console.ReadLine();
        }

        public static async Task<ResponseMarks> GetMinMaxValues(string requestURI)
        {
            try
            {
                HttpClient client = new HttpClient();
                var response = await client.GetAsync(requestURI);
                ResponseMarks responseMarks = null;
                if (!String.IsNullOrEmpty(requestURI))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        responseMarks = new ResponseMarks();
                        string responseContent = await response.Content.ReadAsStringAsync();
                        var content = JsonConvert.DeserializeObject<Dictionary<string, SubjectMarks>>(responseContent);
                        responseMarks.MaxMarks = content.Values.Max(x => x.Math1);
                        responseMarks.MinMarks = content.Values.Min(x => x.Math1);
                    }
                }
                return responseMarks;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}

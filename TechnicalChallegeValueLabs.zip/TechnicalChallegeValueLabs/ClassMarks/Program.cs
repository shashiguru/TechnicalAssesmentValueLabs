﻿using ClassMarks.Models;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;

namespace ClassMarks
{
    class Program
    {
        static async Task Main(string[] args)
        {
            string requestURI= "https://raw.githubusercontent.com/tester1-1/testdata/main/data.json";
            Console.WriteLine(JsonConvert.SerializeObject(await GetMinMaxValues(requestURI)));
            Console.ReadLine();
        }

        public static async Task<ResponseMarks> GetMinMaxValues(string requestURI)
        {
            try
            {
                HttpClient client = new HttpClient();
                var response = await client.GetAsync(requestURI);
                ResponseMarks responseMarks = null;
                if (!String.IsNullOrEmpty(requestURI))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        List<SubjectMarks> marksList = new List<SubjectMarks>();
                        responseMarks = new ResponseMarks();
                        string responseContent = await response.Content.ReadAsStringAsync();
                        var content = JsonConvert.DeserializeObject<ClassesMarks>(responseContent);
                        marksList.Add(content.Class10);
                        marksList.Add(content.Class7);
                        marksList.Add(content.Class8);
                        marksList.Add(content.Class9);
                        marksList.Add(content.ClassN);
                        responseMarks.MaxMarks = marksList.Where(x => x.Math1 == marksList.Max(y => y.Math1)).FirstOrDefault().Math1;
                        responseMarks.MinMarks = marksList.Where(x => x.Math1 == marksList.Min(y => y.Math1)).FirstOrDefault().Math1;
                    }
                }
                return responseMarks;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }
}

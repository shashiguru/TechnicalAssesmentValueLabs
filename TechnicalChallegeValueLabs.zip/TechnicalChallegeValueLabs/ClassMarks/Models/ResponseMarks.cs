﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassMarks.Models
{
   public class ResponseMarks
    {
        public double MaxMarks { get; set; }
        public double MinMarks { get; set; }
    }
}
